<?php

echo "Pls insert this shortcode anywhere on your page: [donate]My Text Here[/donate]";